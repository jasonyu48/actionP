//C++
#include <iostream>
#include <fstream>
#include <chrono>
#include <string>
#include <direct.h>
#include <io.h>
#include <process.h>
 //OpenCV
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
 //Kinect DK
#include <k4a/k4a.hpp>
//#include <k4a/k4a.h>
#include <math.h>
#include <sstream>

#include <k4a/k4a.h>
#include <k4arecord/playback.h>
#include <string>
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include <k4a/k4a.h>
#include <k4arecord/playback.h>
#include <string>


#include "transformation_helpers.h"
#include "turbojpeg.h"
// Timestamp in milliseconds. Defaults to 1 sec as the first couple frames don't contain color
static int playback(std::string input_path, std::string root_path, std::string output_path)
{
    int idx = 1;
    int returnCode = 1;
    k4a_playback_t playback = NULL;
    k4a_calibration_t calibration;
    k4a_transformation_t transformation = NULL;
    k4a_capture_t capture = NULL;

    k4a::image depth_image = NULL;
    k4a::image color_image = NULL;
    k4a::image ir_image = NULL;

    k4a_image_t depth_image_t = NULL;
    k4a_image_t color_image_t = NULL;
    k4a_image_t ir_image_t = NULL;

    k4a_image_t uncompressed_color_image = NULL;

    cv::Mat cv_depth;
    cv::Mat cv_depth_8U;
    cv::Mat cv_irImage;
    cv::Mat cv_irImage_8U;
    k4a::image transformed_depthImage;
    cv::Mat cv_rgbImage_with_alpha;
    cv::Mat cv_rgbImage_no_alpha;
    k4a_result_t result;
    k4a_stream_result_t stream_result = K4A_STREAM_RESULT_SUCCEEDED;
    std::string folderPath = root_path + output_path + "ir/";



    // Open recording
    result = k4a_playback_open(input_path.c_str(), &playback);
    if (result != K4A_RESULT_SUCCEEDED || playback == NULL)
    {
        printf("Failed to open recording %s\n", input_path);
        //goto Exit;
        return 2;
    }
    /*
    //==========================================================================================
    //result:k4a_playback_seek_timestamp
    result = k4a_playback_seek_timestamp(playback, 1000 * 1000, K4A_PLAYBACK_SEEK_BEGIN);
    if (result != K4A_RESULT_SUCCEEDED)
    {
        printf("Failed to seek timestamp %d\n", timestamp);
        return 10;
    }
    */
    if (0 != access(folderPath.c_str(), 0))
    {
        // if this folder not exist, create a new one.
        mkdir(folderPath.c_str());
    }
    //k4a_playback_set_color_conversion(playback, K4A_IMAGE_FORMAT_COLOR_MJPG);

    while (stream_result == K4A_STREAM_RESULT_SUCCEEDED)
    {
        stream_result = k4a_playback_get_next_capture(playback, &capture);
        if (stream_result == K4A_STREAM_RESULT_SUCCEEDED)
        {
            // Process capture here

            if (K4A_RESULT_SUCCEEDED != k4a_playback_get_calibration(playback, &calibration))
            {
                printf("Failed to get calibration\n");
                //goto Exit;
                return 5;
            }

            transformation = k4a_transformation_create(&calibration);
            /*
            // Fetch frame
            depth_image_t = k4a_capture_get_depth_image(capture);
            depth_image = k4a::image::image(depth_image_t);

            if (depth_image_t == 0)
            {
                printf("Failed to get depth image from capture\n");
                //goto Exit;
                continue;
            }
            
            color_image_t = k4a_capture_get_color_image(capture);
            color_image = k4a::image::image(color_image_t);

            if (color_image_t == 0)
            {
                printf("Failed to get color image from capture\n");
                //goto Exit;
                continue;
            }
            */
            ir_image_t = k4a_capture_get_ir_image(capture);
            ir_image = k4a::image::image(ir_image_t);
            if (ir_image_t == 0)
            {
                printf("Failed to get ir image from capture\n");
                //goto Exit;
                continue;
            }
            //Get the camera calibration for the entire K4A device, which is used for all transformation functions.
            // 
            //k4a::calibration k4aCalibration = device.get_calibration(config.depth_mode, config.color_resolution);
            //k4a::transformation k4aTransformation = k4a::transformation(calibration);
            //transformed_IrImage = k4aTransformation.depth_image_to_color_camera(depth_image);
            /*
            k4a::transformation k4aTransformation = k4a::transformation(calibration);
            printf("Step1\n");
            transformed_depthImage = k4aTransformation.depth_image_to_color_camera(depth_image);
            printf("Step2\n");
            cv_rgbImage_with_alpha = cv::Mat(color_image.get_height_pixels(), color_image.get_width_pixels(), CV_8UC4, (void*)color_image.get_buffer());
            printf("Step3\n");
            //====================================================================================================
            cv::cvtColor(cv_rgbImage_with_alpha, cv_rgbImage_no_alpha, cv::COLOR_BGRA2BGR);
            //====================================================================================================
            printf("Step4\n");
            cv_depth = cv::Mat(transformed_depthImage.get_height_pixels(), transformed_depthImage.get_width_pixels(), CV_16U,
                (void*)transformed_depthImage.get_buffer(), static_cast<size_t>(transformed_depthImage.get_stride_bytes()));
            printf("Step5\n");
            normalize(cv_depth, cv_depth_8U, 0, 256 * 256, 32);
            printf("Step6\n");
            cv_depth_8U.convertTo(cv_depth, CV_8U, 1);
            printf("Step7\n");
            */
            cv_irImage = cv::Mat(ir_image.get_height_pixels(), ir_image.get_width_pixels(), CV_16U,
                (void*)ir_image.get_buffer(), static_cast<size_t>(ir_image.get_stride_bytes()));
            //cv::resize(cv_irImage,cv_irImage, cv::Size(1280, 720));
            //printf("Step8\n");
            normalize(cv_irImage, cv_irImage_8U, 0, 256 * 256, 32);
            //printf("Step9\n");
            cv_irImage.convertTo(cv_irImage_8U, CV_8U, 1);
            //printf("Step10\n");
            /*
            cv::imshow("color", cv_rgbImage_no_alpha);
            cv::imshow("depth", cv_depth_8U);
            cv::imshow("ir", cv_irImage_8U);
            */
            printf("ready to save image!\n");
            //save image
            /*
            double time_rgb = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(
                color_image.get_device_timestamp()).count());

            std::string filename_rgb = std::to_string(time_rgb / 1000000) + ".png";

            double time_d = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(
                depth_image.get_device_timestamp()).count());

            std::string filename_d = std::to_string(time_d / 1000000) + ".png";
            */
            //double time_ir = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(ir_image.get_device_timestamp()).count());
            //std::string filename_ir = std::to_string(time_ir / 1000000) + ".png";

            //imwrite("./rgb/" + filename_rgb, cv_rgbImage_with_alpha);
            //imwrite("./depth/" + filename_d, cv_depth_8U);


            imwrite(folderPath + std::to_string(idx) + ".png", cv_irImage_8U);

            printf("Acquiring!\n");

            idx++;

            //k4a_image_release(depth_image);
            k4a_image_release(uncompressed_color_image);
            k4a_capture_release(capture);
            k4a_transformation_destroy(transformation);
            //k4aTransformation.destroy();

            cv_rgbImage_with_alpha.release();
            cv_rgbImage_no_alpha.release();
            cv_depth.release();
            cv_depth_8U.release();
            cv_irImage.release();
            cv_irImage_8U.release();
        }
        else if (stream_result == K4A_STREAM_RESULT_EOF)
        {
            printf("Done\n");
            // End of file reached
            break;
        }
    }
    if (stream_result == K4A_STREAM_RESULT_FAILED)
    {
        printf("Failed to read entire recording\n");
        return 1;
    }

    k4a_playback_close(playback);
    return returnCode;
}

static void print_usage()
{
    printf("Usage: transformation_example capture <output_directory> [device_id]\n");
    printf("Usage: transformation_example playback <filename.mkv> [timestamp (ms)] [output_file]\n");
}

void getFileNames(std::string path, std::vector<std::string>& files)
{
    intptr_t hFile = 0;
    struct _finddata_t fileinfo;
    std::string p;
    if ((hFile = _findfirst(p.assign(path).append("/*").c_str(), &fileinfo)) != -1)
    {
        do
        {
            if ((fileinfo.attrib & _A_SUBDIR))
            {
                if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
                    getFileNames(p.assign(path).append("/").append(fileinfo.name), files);
            }
            else
            {
                files.push_back(fileinfo.name);
            }
        } while (_findnext(hFile, &fileinfo) == 0);
        _findclose(hFile);
    }
}

int main() {
    std::vector<std::string> fileNames;
    std::string path("F:/mkv_record"); // .mkv file save dir
    getFileNames(path, fileNames);
    int returnCode = 0;
    for (const auto& ph : fileNames) {
        //Here we find all the .mkv files in the directory by iterating through them and looping through the handler function
        std::string hz = ph.substr(ph.find('.', 0),4);
        if (hz == ".mkv") {
            std::string target = ph.substr(0, ph.find('.', 0));
            std::string input_path = "F:/mkv_record/" + target + ".mkv";
            std::string root_path = "F:/mkv_output/";
            std::string output_path = target + "/";
            print_usage();
            returnCode = playback(input_path, root_path, output_path);
        }
    }
    return returnCode;
}