﻿////////////////////////////////////////////////////////////////////////////////
//
//    Solution Constants
//
////////////////////////////////////////////////////////////////////////////////

namespace TagGesture
{
    public static class SolutionConstants
    {
        //public const string ReaderHostname = "Speedwayr-10-a6-11.local";
        public const string ReaderHostname = "192.168.0.20";//192.168.1.222
    }
}
