﻿////////////////////////////////////////////////////////////////////////////////
//
//    Tag Gesture
//     改SingleRead 函数以更改接收数据时间
////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.IO;
using System.Data;
using Impinj.OctaneSdk;
using System.Collections.Generic;
using System.Threading;
//using DopplerVisualization;
using System.Windows.Forms;



namespace TagGesture
{
    class Program
    {
        // Create an instance of the ImpinjReader class.
        static ImpinjReader reader = new ImpinjReader();
        //新建一个dataTable
        static DataTable DataDS = new DataTable();
        static DataTable DataDD_forUniqueEPC = new DataTable();
        static DataView dv_forUniqueEPC = DataDS.DefaultView;

        static string filePath = "d:\\lvyizhe\\";

        //static string fileName = "zc_2.csv"; DateTime.Now.ToFileTimeUtc().ToString()+
        static string fileName = DateTime.Now.ToFileTimeUtc().ToString() + "_01_021.csv";
        //static string fileName =  "1.csv";

        static CsvStreamWriter CsvWriter = new CsvStreamWriter(filePath + fileName);
        static double txPowerValue = 0;
        static ushort antennaPort = 1;
        //static FormRealTime DSForm;
        static Hashtable TagsEPC = new Hashtable();
        static List<String> TagNames = new List<String>();


        static void InitTagsEPC()
        {


            //nearby
            TagsEPC.Add("0001", 0);
            TagsEPC.Add("0002", 1);
            //TagsEPC.Add("ED03", 2);
            //TagsEPC.Add("ED04", 3);
            //TagsEPC.Add("ED05", 4);
            //TagsEPC.Add("ED06", 5);
            //TagsEPC.Add("ABCD AAAA AAAA AAAA AAAA E0XX", 0);
            //TagsEPC.Add("ABCD ABCD ABCD ABCD ABCD E100", 1);
            //TagsEPC.Add("ABCD ABCD ABCD ABCD ABCD E114", 2);
            //TagsEPC.Add("ABCD ABCD ABCD ABCD ABCD E019", 3);
            //TagsEPC.Add("AAAA AAAA AAAA AAAA AAAA E0ZZ", 4);

            TagNames.Add("0001");
            TagNames.Add("0002");
            //TagNames.Add("ED03");
            //TagNames.Add("ED04");
            //TagNames.Add("ED05");
            //TagNames.Add("ED06");
            //TagNames.Add("AAAA AAAA AAAA AAAA AAAA 00XX");
            // TagNames.Add("ABCD ABCD ABCD ABCD ABCD E100");
            // TagNames.Add("ABCD ABCD ABCD ABCD ABCD E014");
            // TagNames.Add("ABCD ABCD ABCD ABCD ABCD E019");
            // TagNames.Add("AAAA AAAA AAAA AAAA AAAA 00ZZ");

        }


        static void dasdMain(string[] args)
        {
            try
            {
                //System.Console.WriteLine("Before------------!!!");
                initDataRow();
                InitTagsEPC();

                // Connect to the reader.
                // Change the ReaderHostname constant in SolutionConstants.cs 
                // to the IP address or hostname of your reader.
                //System.Console.WriteLine("Before Connect!!!");
                reader.Connect(SolutionConstants.ReaderHostname);
                //System.Console.WriteLine("Connect!!!");
                // 获取当前默认设置
                // Get the reader features to determine if the 
                // reader supports a fixed-frequency table.
                FeatureSet features = reader.QueryFeatureSet();


                // Get the default settings
                // We'll use these as a starting point
                // and then modify the settings we're 
                // interested in.
                Settings settings = reader.QueryDefaultSettings();
                reportSetting(settings);

                // Use antenna #2
                settings.Antennas.DisableAll();
                settings.Antennas.GetAntenna(1).IsEnabled = true;
                //settings.Antennas.EnableAll();
                settings.Antennas.GetAntenna(1).TxPowerInDbm = 30;
                txPowerValue = settings.Antennas.GetAntenna(1).TxPowerInDbm;
                //settings.Antennas.GetAntenna(1).RxSensitivityInDbm = -55;
                //settings.Antennas.GetAntenna(2).TxPowerInDbm = 32;
                // settings.Antennas.GetAntenna(2).RxSensitivityInDbm = -55;


                //settings.ReaderMode = ReaderMode.AutoSetDenseReader;
                //settings.SearchMode = SearchMode.DualTarget;
                //settings.Session = 2;
                // ReaderMode must be set to DenseReaderM4 or DenseReaderM8.
                settings.ReaderMode = ReaderMode.MaxThroughput;


                // 每读取一个tag就report
                // Send a tag report for every tag read.
                settings.Report.Mode = ReportMode.Individual;

                filterTags(settings);

                if (0 != fixFrequency(features, settings))
                {
                    applicactionClose();
                }
                if (args.Length > 0)
                {
                    double fq = Double.Parse(args[0]);
                    addFrequency(fq, features, settings);

                }

                // Apply the newly modified settings.
                reader.ApplySettings(settings);

                // Assign the TagsReported event handler.
                // This specifies which method to call
                // when tags reports are available.
                reader.TagsReported += OnTagsReported;
                // Read with fix tx power
                singleRead(10000);

                //features.TxPowers = filterPowerTx(features.TxPowers, 0, 80, 5);
                //// multiple tx power read
                //txPowerRead(features, settings);

            }
            catch (OctaneSdkException e)
            {
                // Handle Octane SDK errors.
                //Console.WriteLine("Octane SDK exception: {0}", e.Message);
            }
            catch (Exception e)
            {
                // Handle other .NET errors.
                //Console.WriteLine("Exception : {0}", e.Message);
            }
            Application.Restart();
        }

        static void singleRead(int x)
        {

            reader.Start();
            //DSForm = new FormRealTime(TagNames);
            //Application.Run(DSForm);
            //// Start reading.

            Thread.Sleep(x); //收集31s数据
                             // Wait for the user to press enter.
                             //Console.WriteLine("Press enter to exit.");
                             //Console.ReadLine();


            // Stop reading.
            reader.Stop();

            applicactionClose();
        }

        static void txPowerRead(FeatureSet features, Settings settings)
        {
            foreach (TxPowerTableEntry tx in features.TxPowers)
            {
                // Set the transmit power (in dBm).
                Console.WriteLine("Setting Tx Power to {0} dBm", tx.Dbm);
                settings.Antennas.GetAntenna(antennaPort).TxPowerInDbm = tx.Dbm;
                txPowerValue = tx.Dbm;

                // Apply the new transmit power settings.
                reader.ApplySettings(settings);

                // Start the reader.
                reader.Start();

                // Wait
                Thread.Sleep(2500);

                // Stop the reader.
                reader.Stop();
                Thread.Sleep(10);
            }
            applicactionClose();
        }

        static void OnTagsReported(ImpinjReader sender, TagReport report)
        {
            // This event handler is called asynchronously 
            // when tag reports are available.
            // Loop through each tag in the report 
            // and print the data.
            foreach (Tag tag in report)
            {
                //Console.WriteLine("EPC : {0} Doppler Frequency (Hz) : {1} Current Frequecy: {2}  PeakRSSI ：{3}  PhaseAngle : {4} PhaseDegree :{5}",
                //                    tag.Epc, tag.RfDopplerFrequency.ToString("0.00"), tag.ChannelInMhz, tag.PeakRssiInDbm, tag.PhaseAngleInRadians, ((tag.PhaseAngleInRadians) / Math.PI) * 180);

                //if (stock.Contains(tag.Epc.ToString()))
                //{
                double phaseAngle;
                //0807ding gai
                //if (tag.PhaseAngleInRadians < Math.PI)
                //{
                //    phaseAngle = tag.PhaseAngleInRadians + Math.PI;
                //}
                //else
                //{
                //    phaseAngle = tag.PhaseAngleInRadians;
                //}
                phaseAngle = tag.PhaseAngleInRadians;



                DataRow row = DataDS.NewRow();
                //给列赋值
                DateTime dt = DateTime.Now;

                row["EPC"] = tag.Epc.ToString();
                row["Doppler Shift"] = tag.RfDopplerFrequency.ToString("0.00");
                row["Time"] = tag.FirstSeenTime.ToString();
                row["Antenna"] = tag.AntennaPortNumber;
                row["Tx Power"] = txPowerValue;
                row["Current Frequency"] = tag.ChannelInMhz.ToString();
                row["PeakRSSI"] = tag.PeakRssiInDbm.ToString();
                row["Phase Angle"] = phaseAngle;//tag.PhaseAngleInRadians.ToString();
                row["Phase"] = ((tag.PhaseAngleInRadians) / Math.PI) * 180;
                row["UNIX_time"] = (dt.ToString("yyyyMMdd") + "-" + dt.TimeOfDay.ToString()).Replace(":", string.Empty).Replace(".", string.Empty);
                // row["UNIX_Time"]


                //把有值的列添加到表
                DataDS.Rows.Add(row);



                DataDD_forUniqueEPC = dv_forUniqueEPC.ToTable(true, "EPC");
                //不重复记录数
                int uniqueCount = DataDD_forUniqueEPC.Rows.Count - 1;

                /*Console.WriteLine("EPC : {0}  Phase ：{1} Unique EPC: {2}",
                                        tag.Epc, tag.PhaseAngleInRadians, uniqueCount);*/

                //DSForm.updateTaginfo(row);
                // DSForm.updateTaginfo((int)TagsEPC[tag.Epc.ToString()], (float)(tag.RfDopplerFrequency));
                //DSForm.updateTaginfo((int)TagsEPC[tag.Epc.ToString()], (float)(tag.RfDopplerFrequency));//, tag.FirstSeenTime.LocalDateTime
            }
        }


        static public void initDataRow()
        {
            // 创建表中的列
            DataDS.Columns.Add("EPC");
            DataDS.Columns.Add("Doppler Shift");
            DataDS.Columns.Add("Time");
            DataDS.Columns.Add("Antenna");
            DataDS.Columns.Add("Tx Power");
            DataDS.Columns.Add("Current Frequency");
            DataDS.Columns.Add("PeakRSSI");
            DataDS.Columns.Add("Phase Angle");
            DataDS.Columns.Add("Phase");
            DataDS.Columns.Add("UNIX_time");
            // 初始化列名

            DataRow row = DataDS.NewRow();
            row["EPC"] = "EPC";
            row["Doppler Shift"] = "DopplerShift(Hz)";
            row["Time"] = "Time";
            row["Antenna"] = "Antenna";
            row["Tx Power"] = "TxPower";
            row["Current Frequency"] = "Frequency(MHz)";
            row["PeakRSSI"] = "RSS(dbm)";
            row["Phase Angle"] = "PhaseAngle(Radian)";
            row["Phase"] = "PhaseAngle(Degree)";
            row["UNIX_time"] = "UNIX_time";
            DataDS.Rows.Add(row);

        }

        static public void reportSetting(Settings settings)
        {
            // Tell the reader to include the
            // RF doppler frequency in all tag reports. 
            settings.Report.IncludeDopplerFrequency = true;

            // 允许输出
            settings.Report.IncludeChannel = true;
            settings.Report.IncludePeakRssi = true;
            settings.Report.IncludePhaseAngle = true;
            settings.Report.IncludeFirstSeenTime = true;
            settings.Report.IncludeAntennaPortNumber = true;
        }

        static public void applicactionClose()
        {

            //Console.WriteLine("Press enter to exit.");
            //Console.ReadLine();
            // 写CSV文件
            CsvWriter.AddData(DataDS, 1);
            CsvWriter.Save();


            // Disconnect from the reader.
            reader.Disconnect();
            Console.WriteLine(DataDS.Rows.Count);
            //Console.ReadLine();


        }

        static public void filterTags(Settings settings)
        {
            // Setup a tag filter.
            // Only the tags that match this filter will respond.
            // First, setup tag filter #1.
            // We want to apply the filter to the EPC memory bank.
            settings.Filters.TagFilter1.MemoryBank = MemoryBank.Epc;
            // Start matching at the third word (bit 32), since the 
            // first two words of the EPC memory bank are the
            // CRC and control bits. BitPointers.Epc is a helper
            // enumeration you can use, so you don't have to remember this.
            settings.Filters.TagFilter1.BitPointer = BitPointers.Epc;
            // Only match tags with EPCs that start with "3008"
            //settings.Filters.TagFilter1.TagMask = "FFFFFFFFFFFFFFFFE";
            // This filter is 16 bits long (one word).
            //settings.Filters.TagFilter1.BitCount = 68;

            settings.Filters.TagFilter1.TagMask = "A";
            // This filter is 16 bits long (one word).
            settings.Filters.TagFilter1.BitCount = 4;

            settings.Filters.TagFilter2.MemoryBank = MemoryBank.Epc;
            // Start matching at the third word (bit 32), since the 
            // first two words of the EPC memory bank are the
            // CRC and control bits. BitPointers.Epc is a helper
            // enumeration you can use, so you don't have to remember this.
            settings.Filters.TagFilter2.BitPointer = BitPointers.Epc;
            // Only match tags with EPCs that start with "3008"
            settings.Filters.TagFilter2.TagMask = "C";
            // This filter is 16 bits long (one word).
            settings.Filters.TagFilter2.BitCount = 4;

            // Set the filter mode.
            // Both filters must match.
            settings.Filters.Mode = TagFilterMode.None;


        }

        static public int fixFrequency(FeatureSet features, Settings settings)
        {
            // Specify the transmit frequencies to use.
            // Make sure your reader supports this and
            // that the frequencies are valid for your region.
            List<double> freqList = new List<double>();

            if (!features.IsHoppingRegion)
            {
                //freqList.Add(920.625);
                //freqList.Add(920.875);
                //freqList.Add(921.125);
                //freqList.Add(921.375);
                // freqList.Add(921.625);
                //freqList.Add(921.875);
                //freqList.Add(922.125);
                freqList.Add(922.375);
                //freqList.Add(922.625);
                //freqList.Add(922.875);
                //freqList.Add(923.125);
                //freqList.Add(923.375);
                //freqList.Add(923.625);
                //freqList.Add(923.875);
                //freqList.Add(924.125);
                //freqList.Add(924.375);
                // 其他符合标准的频率值
                //920625, 920875, 921125, 921375, 921625, 921875, 922125, 922375, 922625, 922875, 923125, 923375, 923625, 923875, 924125, 924375
                // 921.625;921.875;922.125;922.375;922.625;922.875;923.125;923.375;923.625;923.875;924.125;924.375;
                settings.TxFrequenciesInMhz = freqList;

                return 0;
            }
            else
            {
                //Console.WriteLine("This reader does not allow the transmit frequencies to be specified.");
                return -1;
            }
        }

        static public int addFrequency(double fenquency, FeatureSet features, Settings settings)
        {
            // Specify the transmit frequencies to use.
            // Make sure your reader supports this and
            // that the frequencies are valid for your region.
            List<double> freqList = new List<double>();

            if (!features.IsHoppingRegion)
            {
                freqList.Add(fenquency);
                // 其他符合标准的频率值
                //920625, 920875, 921125, 921375, 921625, 921875, 922125, 922375, 922625, 922875, 923125, 923375, 923625, 923875, 924125, 924375
                // 921.625;921.875;922.125;922.375;922.625;922.875;923.125;923.375;923.625;923.875;924.125;924.375;
                settings.TxFrequenciesInMhz = freqList;

                return 0;
            }
            else
            {
                //Console.WriteLine("This reader does not allow the transmit frequencies to be specified.");
                return -1;
            }
        }
        static public List<Impinj.OctaneSdk.TxPowerTableEntry> filterPowerTx(List<Impinj.OctaneSdk.TxPowerTableEntry> tp, int start, int end, int num)
        {
            List<Impinj.OctaneSdk.TxPowerTableEntry> powerList = new List<Impinj.OctaneSdk.TxPowerTableEntry>();
            int step = (end - start) / num;
            //for (int i = end; i >= start; i -= step)
            //{
            //    powerList.Add(tp[i]);
            //}
            for (int i = start; i <= end; i += step)
            {
                powerList.Add(tp[i]);
            }
            return powerList;
        }

    }
}
