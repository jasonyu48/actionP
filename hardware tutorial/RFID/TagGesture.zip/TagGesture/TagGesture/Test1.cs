﻿using System;
namespace TagGesture
{
	public class Class1
	{
		public Class1()
		{
		}
	}
}

